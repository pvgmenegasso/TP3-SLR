package tp3;
import java.io.* ;


public class HelloData implements Serializable {
	
	
	public String message ;
	transient String transientMessage   ;
	
	
	public static long serialVersionUID = 1L ;
	
	public HelloData(String message, String transientMessage)
	{
		this.message = message ;
		this.transientMessage = transientMessage ; 
	}
	
	public void printdata()
	{
		System.out.println(message+" e "+transientMessage);
	}
}




