package tp3;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HelloData data1 = new HelloData("one", "two") ;
		HelloData data2 = new HelloData("three", "four") ;
		HelloData data3 = null ;
		
		DataSerializer ds1 = new DataSerializer(data1) ;
		DataSerializer ds2 = new DataSerializer(data2) ;

	}

}
