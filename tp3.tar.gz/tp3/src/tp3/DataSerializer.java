package tp3;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class DataSerializer implements Serializable
{
	public final static long serialVersionUID = 1L ;
	
	private HelloData data = null ;
	
	
	public DataSerializer(String str1, String str2)
	{
		this.data = new HelloData(str1, str2) ;
	}
	
	public DataSerializer(HelloData data)
	{
		this.data = data ;
	}
	
	public void serialize()
	{
		FileOutputStream fout = null;
		ObjectOutputStream ofout = null ;
		
		try
		{
			fout = new FileOutputStream("mydata.ser") ;
			ofout = new ObjectOutputStream(fout) ;
			ofout.writeObject(data);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				ofout.close() ;

			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			try
			{
				fout.close() ;
				ofout.close();

			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			
		}
	}
	
	
}