package tp3;
import java.io.* ;

public class DataUnserializer implements Serializable 
{
	
public static final long serialVersionUID = 1L ;

public HelloData unserialize()
{
	
	HelloData data = null ;
	FileInputStream fout = null ;
	ObjectInputStream ofout = null ;
	
	try
	{
		fout = new FileInputStream("mydata.ser") ;
		ofout = new ObjectInputStream(fout) ;
		data = (HelloData)ofout.readObject() ;
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			fout.close() ;

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		try
		{
			ofout.close();

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		

		
		
	}
	
	return data ;
}
	


}
